<?php

return [
    '646a68c515e9329077022876' => [
        'user',
    ],
    '648accc36794bee3b5016c42' => [
        'user',
    ],
    '648acca4ebc46b8e67046553' => [
        'user',
    ],
    '646a68de7acd6a978a0698e6' => [
        'user',
    ],
];
