<?php

return [
    'admin' => [
        'type' => 1,
    ],
    'user' => [
        'type' => 1,
    ],
    'agent' => [
        'type' => 1,
    ]
];
