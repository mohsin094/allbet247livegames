<?php

namespace app\modules\user\components;

use common\components\CommonApiController;


class ApiController extends CommonApiController
{

}