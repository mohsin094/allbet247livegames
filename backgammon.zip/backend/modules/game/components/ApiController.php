<?php

namespace backend\modules\game\components;

use \common\components\CommonApiController;

class ApiController extends CommonApiController
{
	
}