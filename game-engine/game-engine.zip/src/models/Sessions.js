export default {
	name: 'sessions'
}