function EventObj(eventName, data) {
	this.eventName = eventName;
	this.data = data;
}

export default EventObj