export default function(req, res, next) {

	next();
}