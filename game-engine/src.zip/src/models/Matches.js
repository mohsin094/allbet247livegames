export default {
	name: "matches",
	status: {
		WAITING: 'waiting',
		PLAYING: 'playing',
		FINISHED: 'finished',
		EXPIRED: 'expired'
	}
}

