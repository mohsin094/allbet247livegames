import app from '#components/App'

app.init();
