import path from 'path'

path.basePath = process.cwd();

export default path