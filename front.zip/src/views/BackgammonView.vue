<template>
	<Board/>
</template>
<script>
	import Board from '@/components/Board.vue';
	export default{
		components: {
        Board
      }
  }
</script>
<style>
	.main-wrapper{
		border-top: 1.5px solid;	
		background: linear-gradient(271.91deg, #784242 6.76%, #1A1F27 25.34%, #676D75 53.35%, #1A1F27 80.27%, #7B828C 92.89%, #427861 92.9%);
	}
</style>