<template>
	<h2>Terms of service</h2>
</template>